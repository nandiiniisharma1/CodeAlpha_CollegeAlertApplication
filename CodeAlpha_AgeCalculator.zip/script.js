const dayInput   = document.getElementById('day');
const monthInput = document.getElementById('month');
const yearInput  = document.getElementById('year');
const calcBtn    = document.getElementById('calcBtn');
const errorEl    = document.getElementById('error');
const resultGrid = document.getElementById('resultGrid');
const resYears   = document.getElementById('resYears');
const resMonths  = document.getElementById('resMonths');
const resDays    = document.getElementById('resDays');
const dobLine    = document.getElementById('dobLine');

const MONTHS = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December'
];

function daysInMonth(month, year) {
  return new Date(year, month, 0).getDate();
}

function showError(msg) {
  errorEl.textContent = msg;
  errorEl.classList.add('visible');
  [dayInput, monthInput, yearInput].forEach(el => el.classList.add('invalid'));
}

function clearError() {
  errorEl.textContent = '';
  errorEl.classList.remove('visible');
  [dayInput, monthInput, yearInput].forEach(el => el.classList.remove('invalid'));
}

function animateNumber(el, target) {
  const duration = 600;
  const start    = performance.now();
  const from     = 0;

  function step(now) {
    const elapsed  = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased    = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(from + (target - from) * eased);
    if (progress < 1) requestAnimationFrame(step);
  }

  requestAnimationFrame(step);
}

function calculate() {
  clearError();

  const day   = parseInt(dayInput.value,   10);
  const month = parseInt(monthInput.value, 10);
  const year  = parseInt(yearInput.value,  10);

  if (!dayInput.value || !monthInput.value || !yearInput.value) {
    showError('Please fill in all three fields.');
    return;
  }

  if (isNaN(day) || isNaN(month) || isNaN(year)) {
    showError('Please enter valid numeric values.');
    return;
  }

  if (month < 1 || month > 12) {
    showError('Month must be between 1 and 12.');
    return;
  }

  if (day < 1 || day > daysInMonth(month, year)) {
    showError('Day is out of range for the selected month.');
    return;
  }

  const today = new Date();
  const birth = new Date(year, month - 1, day);

  if (birth > today) {
    showError('Date of birth cannot be in the future.');
    return;
  }

  if (year < 1900) {
    showError('Year must be 1900 or later.');
    return;
  }

  let years  = today.getFullYear() - birth.getFullYear();
  let months = today.getMonth()    - birth.getMonth();
  let days   = today.getDate()     - birth.getDate();

  if (days < 0) {
    months -= 1;
    days   += daysInMonth(today.getMonth(), today.getFullYear());
  }

  if (months < 0) {
    years  -= 1;
    months += 12;
  }

  resultGrid.classList.add('visible');
  dobLine.classList.add('visible');

  animateNumber(resYears,  years);
  animateNumber(resMonths, months);
  animateNumber(resDays,   days);

  dobLine.textContent =
    'Born on ' + MONTHS[month - 1] + ' ' + day + ', ' + year;
}

calcBtn.addEventListener('click', calculate);

[dayInput, monthInput, yearInput].forEach(input => {
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') calculate();
  });
});
